import 'package:flutter/material.dart';

void main() => runApp(const WasalniApp());

class WasalniApp extends StatelessWidget {
  const WasalniApp({super.key});

  @override
  Widget build(BuildContext context) {
    const green = Color(0xFF087F5B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'وصلني',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: green),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selected = 0;
  final _from = TextEditingController();
  final _to = TextEditingController();

  @override
  void dispose() {
    _from.dispose();
    _to.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homeContent(),
      const _SimplePage(
        icon: Icons.receipt_long,
        title: 'طلباتي',
        subtitle: 'ستظهر رحلاتك وطلباتك هنا.',
      ),
      const _SimplePage(
        icon: Icons.person_outline,
        title: 'حسابي',
        subtitle: 'إعدادات الحساب ستتوفر هنا.',
      ),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('وصلني', style: TextStyle(fontWeight: FontWeight.bold)),
          centerTitle: false,
          actions: [
            IconButton(
              tooltip: 'الإشعارات',
              onPressed: () => _message('لا توجد إشعارات جديدة حاليًا'),
              icon: const Icon(Icons.notifications_none),
            ),
          ],
        ),
        body: SafeArea(child: pages[_selected]),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _selected,
          onDestinationSelected: (value) => setState(() => _selected = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'طلباتي'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _homeContent() {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(
              colors: [Color(0xFF087F5B), Color(0xFF12A879)],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مشوارك يبدأ من هنا', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
              SizedBox(height: 8),
              Text('اطلب وسيلة نقل بسهولة مع وصلني', style: TextStyle(color: Colors.white, fontSize: 15)),
              SizedBox(height: 18),
              Icon(Icons.local_taxi, color: Colors.white, size: 54),
            ],
          ),
        ),
        const SizedBox(height: 22),
        const Text('إلى أين تريد الذهاب؟', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 14),
        TextField(
          controller: _from,
          decoration: InputDecoration(
            labelText: 'موقع الانطلاق',
            prefixIcon: const Icon(Icons.my_location),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _to,
          decoration: InputDecoration(
            labelText: 'الوجهة',
            prefixIcon: const Icon(Icons.location_on_outlined),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
          ),
        ),
        const SizedBox(height: 16),
        SizedBox(
          height: 52,
          child: FilledButton.icon(
            onPressed: () {
              if (_from.text.trim().isEmpty || _to.text.trim().isEmpty) {
                _message('أدخل موقع الانطلاق والوجهة أولًا');
                return;
              }
              showDialog<void>(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('تم تجهيز طلبك'),
                  content: Text('من: ${_from.text.trim()}\nإلى: ${_to.text.trim()}\n\nهذه نسخة تجريبية؛ لم يتم إرسال الطلب إلى سائق.'),
                  actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
                ),
              );
            },
            icon: const Icon(Icons.search),
            label: const Text('البحث عن رحلة'),
          ),
        ),
        const SizedBox(height: 24),
        const Text('خدماتنا', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const Row(
          children: [
            Expanded(child: _ServiceCard(icon: Icons.directions_car, title: 'مشاوير')),
            SizedBox(width: 12),
            Expanded(child: _ServiceCard(icon: Icons.delivery_dining, title: 'توصيل')),
            SizedBox(width: 12),
            Expanded(child: _ServiceCard(icon: Icons.schedule, title: 'حجز مسبق')),
          ],
        ),
        const SizedBox(height: 20),
        const Text('ملاحظة: هذه نسخة أولية للواجهة فقط، ولا تتضمن بعد تسجيل الدخول أو الخرائط أو ربط السائقين والدفع.', style: TextStyle(color: Colors.black54, height: 1.5)),
      ],
    );
  }

  void _message(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}

class _ServiceCard extends StatelessWidget {
  const _ServiceCard({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
        child: Column(
          children: [
            Icon(icon, size: 28, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 8),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

class _SimplePage extends StatelessWidget {
  const _SimplePage({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 64, color: Theme.of(context).colorScheme.primary),
          const SizedBox(height: 16),
          Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Text(subtitle, textAlign: TextAlign.center),
        ],
      ),
    ),
  );
}
