# وصلني (Wasalni) — Flutter prototype

This is an early UI prototype for an Arabic ride/delivery app.

## Build on GitHub
1. Upload the contents of this project to the root of your GitHub repository.
2. Ensure `.github/workflows/build-android.yml` is included.
3. Open the **Actions** tab and run **Build Wasalni Android APK**, or push/commit to `main`.
4. When the workflow succeeds, open the run and download the `wasalni-release-apk` artifact.

This is a UI prototype only. It does not yet include backend services, real maps, authentication, dispatching, payments, or live drivers.
